// cypress/e2e/03-day1-visit.cy.ts
// use https://uitestingplayground.com/textinput
// use https://uitestingplayground.com as baseUrl
// use /textinput
// This Cypress test file demonstrates the use of the visit command
// to navigate to different web pages and perform assertions
// using Cypress commands and Mocha hooks
describe('visit command', () => {
    // Test case 1
    // Visiting an external URL
    it('visits an external URL', () => {
        // cy.visit('https://uitestingplayground.com');
        cy.visit('/');
    });
    // Test case 2
    // Visiting internal application routes
    it('visits an external URL', () => {
        // cy.visit('https://uitestingplayground.com/textinput');
        cy.visit('/textinput');
    });
    // Test case 3
    // Visiting another internal application route
    it('visits an external URL', () => {
        // cy.visit('https://uitestingplayground.com/dynamicid');
        cy.visit('/dynamicid');
    });
});
// Using Mocha hooks to set up preconditions for tests
describe.only('visit command with hooks', () => {
    // runs before each test in the block
    beforeEach(() => {
        cy.visit('/textinput');
    });
    // Test case 1
    // Printing the current URL to the Cypress console
    it('prints the current URL', () => {
        cy.url().then((url) => {
            cy.log(`Current URL: ${url}`);
        });
    });
    // Test case 2
    // Validating the URL using expect assertion
    it('validates the URL with expect', () => {
        cy.url().then((url) => {
            expect(url).to.include('/textinput');
        });
    });
    // Test case 3
    // Validating the page title using expect assertion
    it('validates the page title with expect', () => {
        cy.title().then((title) => {
            expect(title).to.equal('Text Input');
        });
    });
    // Test case 4
    // Validating actions (type, click) with should assertion
    it('validates actions with should', () => {
        cy.get('#newButtonName').type('Cypress Test').should('have.value', 'Cypress Test');
        cy.get('#updatingButton').click().should('have.text', 'Cypress Test');
    });
    
});