// cypress/e2e/05-day1-xpath-selectors.cy.ts
// install cypress-xpath first before using this
// use /dynamicid
// In your  terminal run the command: npm i @cypress/xpath
// In your framework support file [cypress/support/e2e.{js/ts}] add at the top of the file the next line: require('@cypress/xpath')
describe('XPath Selectors in Cypress', () => {
    // runs before each test in the block
    beforeEach(() => {
        cy.visit('/dynamicid');
    });
    // Test case 1
    // Using XPath to locate an element by its text content
    it('locates element using XPath', () => {
        cy.xpath("//*[text()='Button with Dynamic ID']").should('be.visible').and('have.text', 'Button with Dynamic ID');
    });
    // Test case 2
    // Using XPath to locate a button within a div
    it('locates button using XPath within a div', () => {
        cy.xpath("//div//button").should('be.visible').and('have.text', 'Button with Dynamic ID');
    });
    // Test case 3
    // Using XPath with attribute selector to locate a button by its type attribute
    it('locates button using XPath with attribute', () => {
        cy.xpath("//button[@type='button']").should('be.visible').and('have.text', 'Button with Dynamic ID');
    });
    // Test case 4
    // Using XPath with class attribute to locate a button by its class name
    it('locates button using XPath with class', () => {
        cy.xpath("//button[contains(@class, 'btn') and contains(@class, 'btn-primary')]").should('be.visible').and('have.text', 'Button with Dynamic ID');
    });

});

// [#2] Practice more CSS/XPath selectors here: https://uitestingplayground.com/classattr
// 1. Make a new test suite
// 2. Use beforeEach hook to visit /classattr page
// 3. Write 2 test/ cases using XPath selectors:
//    - find an element by its text e.g."//*[text()='Correct variant is']"
//    - find an element by its text "//tagname[@attribute='value']"
// 4. Write 2 test cases using CSS selectors:
//    - find an element by its class e.g. ".className" then make sure of its css property using .should('have.css', 'property', 'value')
//    - find an element by its attribute e.g. "[attribute='value']" then make sure of its css property using .should('have.css', 'property', 'value')