// cypress/e2e/02-day1-typescript.cy.ts
// This Cypress test file demonstrates basic TypeScript features
describe("Typescript Introduction", () => {
  // Test case 1
  it("typescript introduction", () => {
    // Variable declarations with type annotations
    // string variable
    let message: string = "Hello, Cypress with TypeScript!";
    // number variable
    let count: number = 5;
    // boolean variable
    let isActive: boolean = true;
    // any variable
    let data: any = { "name": "ahmad" };
    // array of strings
    let fruits: string[] = ["apple", "banana", "cherry"];
    // function with typed parameters and return type
    // function to greet a person by name
    // takes a string parameter 'name' and returns a greeting string
    function greet(name: string): string {
      return `Hello, ${name}!`;
    }
    // log outputs to Cypress console
    cy.log(message);
    cy.log(`Count: ${count}`);
    cy.log(`Is Active: ${isActive}`);
    cy.log(`Data Name: ${data.name}`);
    cy.log(`Fruits: ${fruits.join(", ")}`);
    cy.log(greet("Ahmad"));
    // interface definition
    // defining a Person interface
    // with name and age properties
    interface Person{
      name: string;
      age: number;
    }
    // function that takes a Person object and returns a formatted string
    // demonstrating the use of the Person interface
    function introduce(person: Person): string {
      return `My name is ${person.name} and I am ${person.age} years old.`;
    }
    // log output to Cypress console
    cy.log(introduce({ name: "Ahmad", age: 30 }));
    
  });
});