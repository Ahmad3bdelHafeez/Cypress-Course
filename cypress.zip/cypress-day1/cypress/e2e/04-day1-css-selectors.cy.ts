// cypress/e2e/04-day1-css-selectors.cy.ts
// use /dynamicid
// This Cypress test file demonstrates the use of various CSS selectors
// to locate and interact with elements on a web page
// The tests include examples of using cy.contains, cy.get with cy.find,
// CSS attribute selectors, and CSS class selectors
describe('CSS Selectors in Cypress', () => {
    // runs before each test in the block
    beforeEach(() => {
        cy.visit('/dynamicid');
    });
    // Test case 1
    // Using cy.contains to locate an element by its text content
    it('locates element using cy.contains', () => {
        cy.contains('Button with Dynamic ID').should('be.visible').and('have.text', 'Button with Dynamic ID');
    });
    // Test case 2
    // Using cy.get combined with cy.find to locate a button within a div
    it('locates button using cy.get and cy.find', () => {
        cy.get('div').find('button').should('be.visible').and('have.text', 'Button with Dynamic ID');
    });
    // Test case 3
    // Using CSS attribute selector to locate a button by its type attribute
    it.skip('locates button using CSS attribute selector', () => {
        cy.get('button[type="button"]').should('be.visible').and('have.text', 'Button with Dynamic ID');
    });
    // Test case 4
    // Using CSS class selector to locate a button by its class name
    it('locates button using CSS class selector', () => {
        cy.get('.btn.btn-primary').should('be.visible').and('have.text', 'Button with Dynamic ID');
    });
    
});