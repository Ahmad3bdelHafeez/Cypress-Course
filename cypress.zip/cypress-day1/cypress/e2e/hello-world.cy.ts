describe('template spec', () => {
  it('passes', () => {
    cy.visit('www.google.com')
  })
})