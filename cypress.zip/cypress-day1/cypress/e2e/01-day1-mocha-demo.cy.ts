// cypress/e2e/01-day1-mocha-demo.cy.ts
// test suite definition
describe("Mocha Demo", () => {
    // hook to run before all tests
    before(() => {
        cy.log("Running before all tests");
    });
    // hook to run after all tests
    after(() => {
        cy.log("Running after all tests");
    });
    // hook to run before each test
    beforeEach(() => {
        cy.log("Running before each test");
    });
    // hook to run after each test
    afterEach(() => {
        cy.log("Running after each test");
    });
    // test case 1
    // log a message
    it("Test Case 1", () => {
        cy.log("Executing Test Case 1");
    });
    // test case 2
    // log a message
    it("Test Case 2", () => {
        cy.log("Executing Test Case 2");
    });
    // test case 3
    // log a message
    it("Test Case 3", () => {
        cy.log("Executing Test Case 3");
    });
    // test case 4
    // log a message
    it("Test Case 4", () => {
        cy.log("Executing Test Case 4");
    });
});


// [#1] Practice mocha hooks
// 1. Make a new test suite
// 2. Use all mocha hooks (before, after, beforeEach, afterEach) to log messages
// 3. Write 3 test cases that log different messages
