import { defineConfig } from "cypress";

export default defineConfig({
  
  e2e: {
    reporter: 'cypress-mochawesome-reporter',
    reporterOptions: {
      charts: true,
      reportPageTitle: 'Report Final',
      embeddedScreenshots: true,
      inlineAssets: true,
      saveAllAttempts: true,
      videoOnFailOnly: true,
    },
    baseUrl: "https://uitestingplayground.com",
    setupNodeEvents(on, config) {
      // implement node event listeners here
      require('cypress-mochawesome-reporter/plugin')(on);
    },
    pageLoadTimeout: 5000, // Set page load timeout to unlimited
  },
  video:true,
});
