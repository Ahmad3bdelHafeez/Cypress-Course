class Login{
    private usernameInput: string = '#user-name';
    private passwordInput: string = '#password';
    private loginButton: string = '#login-button';
    private errorMessage: string = '[data-test="error"]';
    submitLogin(username: string, password: string){
        cy.get(this.usernameInput).type(username);
        cy.get(this.passwordInput).type(password);
        cy.get(this.loginButton).click();
    }
    visit(){
        cy.visit('https://www.saucedemo.com/');
    }
    getErrorMessage(){
        return cy.get(this.errorMessage);
    }
}

export const LoginPage = new Login();