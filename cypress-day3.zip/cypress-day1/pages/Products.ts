class Produsts{
    private productTitle: string = '.title';
    private firstProductAddToCartButton: string = '#add-to-cart-sauce-labs-backpack';
    private firstProductRemoveButton: string = '#remove-sauce-labs-backpack';
    private shoppingCartBadge: string = '.shopping_cart_link';
    private shoppingCartBadgeNumber: string = '.shopping_cart_badge';

    getProductTitle(){
        return cy.get(this.productTitle);
    }
    addFirstProductToCart(){
        cy.get(this.firstProductAddToCartButton).click();
    }
    removeFirstProductFromCart(){
        cy.get(this.firstProductRemoveButton).click();
    }
    clickOnShoppingCartBadge(){
        return cy.get(this.shoppingCartBadge).click();
    }
    getShoppingCartBadgeNumber(){
        return cy.get(this.shoppingCartBadgeNumber);
    }
}

export const ProductsPage = new Produsts();