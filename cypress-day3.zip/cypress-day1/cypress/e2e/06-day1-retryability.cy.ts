// cypress/e2e/06-day1-retryability.cy.ts
// Retryability in Cypress
// use /loaddelay
// use /clientdelay
// This Cypress test file demonstrates retryability scenarios
// including visiting pages with load delays and handling client-side delays
//Cypress.config('defaultCommandTimeout', 10000); // set default command timeout to 10 seconds
describe('Retryability in Cypress', () => {
    // test case 1
    // visit page without load delay
    it('visits page without load delay', () => {
        cy.visit('/loaddelay');
        cy.url().should('include', '/loaddelay');
    });
    // test case 2
    
    // visit page with load delay
    // use pageLoadTimeout: 0 in cypress.config.ts to set custom timeout for page load
    it('visits page with load delay', () => {
        cy.visit('/loaddelay', { timeout: 20000 });
        cy.url().should('include', '/loaddelay');
    });
    // test case 3
    // handle client side delay
    // click the button and wait for the success message to appear
    it.only('handles client side delay', () => {
        cy.visit('/clientdelay');
        cy.get('#ajaxButton').click();
        cy.get('.bg-success', { timeout: 15000 }).should('be.visible').and('have.text', 'Data calculated on the client side.');
    });
    
});
// [#3] Practice more retryability scenarios here: https://uitestingplayground.com/progressbar
// 1. Make a new test suite
// 2. Use beforeEach hook to visit /progressbar page
// 3. Write 1 test case demonstrating retryability:
//    - click the start button
//    - assert that the progress bar reaches 100%
//    - use a custom timeout if necessary

