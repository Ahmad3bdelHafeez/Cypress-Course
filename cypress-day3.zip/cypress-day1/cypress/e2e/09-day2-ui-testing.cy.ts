// testing login page of https://www.saucedemo.com/
// This Cypress test file demonstrates UI testing of the login functionality
// including both positive and negative test cases
import {LoginPage} from '../../pages/Login';
import {ProductsPage} from '../../pages/Products';
describe('UI Testing of Login Page', () => {
    // runs before each test in the block
    beforeEach(() => {
        // cy.visit('https://www.saucedemo.com/');
        LoginPage.visit();
    });
    // Test case 1
    // Validate successful login with valid credentials
    // type username and password and click login button
    // Verify that the user is redirected to the inventory page
    // and the products title is visible and have text 'Products'
    it('validates successful login with valid credentials', () => {
        // cy.get('#user-name').type('standard_user');
        // cy.get('#password').type('secret_sauce');
        // cy.get('#login-button').click();
        cy.login('standard_user', 'secret_sauce');
        // cy.pause();
        // LoginPage.submitLogin('standard_user', 'secret_sauce');
        cy.url().should('include', '/inventory.html');
        cy.get('.title').should('be.visible').and('have.text', 'Products');
    });
    // Test case 2
    // Validate unsuccessful login with invalid credentials
    // type invalid username and password and click login button
    // Verify that the error message is visible and contains the correct text
    it('validates unsuccessful login with invalid credentials', () => {
        // cy.get('#user-name').type('invalid_user');
        // cy.get('#password').type('invalid_password');
        // cy.get('#login-button').click();
        LoginPage.submitLogin('invalid_user', 'invalid_password');
        // cy.get('[data-test="error"]').should('be.visible')
        //   .and('have.text', 'Epic sadface: Username and password do not match any user in this service');
        LoginPage.getErrorMessage().should('be.visible')
          .and('have.text', 'Epic sadface: Username and password do not match any user in this service');
    });
    // Test case 3
    // Validate clicking on first product's add to cart button after successful login
    // Verify that the shopping cart badge is visible and shows the correct number of items
    it('validates adding first product to cart after login', () => {
        cy.login('standard_user', 'secret_sauce');
        ProductsPage.addFirstProductToCart();
        ProductsPage.getShoppingCartBadgeNumber().should('be.visible').and('have.text', '1');
        ProductsPage.clickOnShoppingCartBadge();
        // cy.get('.shopping_cart_link').should('be.visible').and('have.text', '1');
    });
});