// cypress/e2e/07-day1-ui-scenarios.cy.ts
// [#4] Practice more ui scenarios here: https://uitestingplayground.com/click
// 1. Make a new test suite
// 2. Use beforeEach hook to visit /click page
// 3. Write 2 test cases demonstrating different assertions after clicking the button:
//    - first test case: assert that the button has class 'btn-success' after clicking
//    - second test case: assert that the button has style 'background-color: rgb(40, 167, 69)' after clicking



