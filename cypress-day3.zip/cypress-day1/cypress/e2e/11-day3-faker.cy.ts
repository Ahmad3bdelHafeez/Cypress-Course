// cypress/e2e/10-day3-faker.cy.ts
// This Cypress test file demonstrates the use of the Faker library to generate fake user data
// and log it to the Cypress console.
// Import the Faker library
const { fakerDE: faker } = require('@faker-js/faker');
// Test suite for Faker
describe('Faker Test Suite', () => {
    // Test case 1
    // Generate fake user data and log it to the Cypress console
    // including first name, last name, email, phone number, and address
    // Use faker.person.firstName(), faker.person.lastName(), faker.internet.email(), faker.phone.number(), faker.location.streetAddress()
    it('generates fake user data and logs it to console', () => {
        let firstName = faker.person.firstName();
        const lastName = faker.person.lastName();
        const email = faker.internet.email();
        const phoneNumber = faker.phone.number();
        const address = faker.location.streetAddress();
        cy.log('First Name: ' + firstName);
        cy.log('Last Name: ' + lastName);
        cy.log('Email: ' + email);
        cy.log('Phone Number: ' + phoneNumber);
        cy.log('Address: ' + address);
    });
});