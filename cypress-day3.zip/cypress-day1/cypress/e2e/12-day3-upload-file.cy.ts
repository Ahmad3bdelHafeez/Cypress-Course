describe('File Upload Test Suite', () => {
    // Test case 1
    // Upload a file using cypress-file-upload plugin
    it('should upload a file successfully', () => {
        // Visit the file upload page https://the-internet.herokuapp.com/upload
        cy.visit('https://the-internet.herokuapp.com/upload');
        // Define the file to be uploaded from fixtures folder
        // Upload the file called test.txt
        // Click the upload button
        cy.get('#file-upload').attachFile("ahmad.txt");
        cy.get('#file-submit').click();
        // Verify the file upload was successful
        cy.contains('File Uploaded!').should('be.visible').and('have.text', 'File Uploaded!');
        cy.get('#uploaded-files').should('be.visible').and('contain', 'ahmad.txt');
        // Verify the file upload was successful

        // and('contain.text', 'index.html');
    });
});