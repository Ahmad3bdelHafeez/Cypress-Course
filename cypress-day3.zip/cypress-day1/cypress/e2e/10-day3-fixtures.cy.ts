import { User } from '../model';
describe('Using Fixtures in Cypress', () => {
    // Test case 1
    // Load fixture data using cy.fixture() in example fixture and validate its content
    it('loads fixture data and validates its content', () => {
        cy.fixture('example').then((data) => {
            cy.log(data.username);
            cy.log(data.password);
        });
    });
    // Test case 2
    // Load fixtures data using interface and validate its content equal the same values
    it('loads fixture data using interface and validates its content', () => {
        cy.fixture<User>('example').then((user) => {
            expect(user.username).to.equal('ahmad');
            expect(user.password).to.equal('pwd');
        });
    });
    // Test case 3
    // Use fixture data from user interface in model file and example fixture to fill out a form on a sample page
    // use /sampleapp page
    it('uses fixture data to fill out a form on sample page', () => {
        cy.fixture<User>('example').then((user) => {
            cy.visit('/sampleapp'); // Replace with actual sample app URL
            cy.get('[name="UserName"]').type(user.username);
            cy.get('[name="Password"]').type(user.password);
            cy.get('#login').click();
            // Add assertions as needed to validate form submission
            cy.get('#loginstatus').should('be.visible').and('contain.text', 'Welcome, ' + user.username);
            cy.get('#login').click();
        });
    });

    
    // Test case 4
    // Load fixture list of data to fill out a form multiple times
    // and validate each submission
    it('loads fixture list of data to fill out a form multiple times', () => {
        cy.fixture<User[]>('users.json').its('users-group1').then((users) => {
            users.forEach((user) => {
                cy.visit('/sampleapp'); // Replace with actual sample app URL
                cy.get('[name="UserName"]').type(user.username);
                cy.get('[name="Password"]').type(user.password);
                cy.get('#login').click();  
                // Add assertions as needed to validate form submission
                if(user.valid) {
                    cy.get('#loginstatus').should('be.visible').and('contain.text', 'Welcome, ' + user.username);
                } else {
                    cy.get('#loginstatus').should('be.visible').and('contain.text', 'Invalid username/password');
                }
                // cy.get('#loginstatus').should('be.visible').and('contain.text', 'Welcome, ' + user.username);
                cy.get('#login').click();
            });
        });
    });
    
});