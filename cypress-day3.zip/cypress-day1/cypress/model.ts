export interface User{
    valid: boolean;
    username: string;
    password: string;
}