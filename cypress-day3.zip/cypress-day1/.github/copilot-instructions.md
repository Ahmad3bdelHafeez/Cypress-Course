# Copilot Instructions for Cypress Test Automation Project

## Project Overview
This is a Cypress test automation project using TypeScript for UI testing against [UI Testing Playground](https://uitestingplayground.com/). The project demonstrates various Cypress testing patterns and best practices.

## Key Architecture Patterns

### Test Organization
- Tests are organized in `cypress/e2e/` with descriptive filenames following pattern `XX-day1-[concept].cy.ts`
- Each test file focuses on specific concepts (e.g., selectors, retryability, UI scenarios)
- Support files and custom commands in `cypress/support/`
- Test data fixtures in `cypress/fixtures/`

### Core Testing Patterns
1. **Selector Strategies**:
   - CSS selectors (see `04-day1-css-selectors.cy.ts`)
   - XPath selectors (see `05-day1-xpath-selectors.cy.ts`) - requires `@cypress/xpath` plugin
   - Prefer stable selectors over dynamic IDs

2. **Test Structure**:
   ```typescript
   describe('Feature', () => {
     beforeEach(() => {
       cy.visit('/relative-path'); // Uses baseUrl from config
     });
     
     it('should do something', () => {
       // Test implementation
     });
   });
   ```

3. **Retryability Pattern** (`06-day1-retryability.cy.ts`):
   - Use timeouts for slow loading elements: `{ timeout: 15000 }`
   - Configure page load timeout in `cypress.config.ts`
   - Handle both page load and client-side delays

## Development Workflow

### Setup & Running Tests
1. Install dependencies:
   ```bash
   npm install
   ```

2. Run tests in Chrome:
   ```bash
   npm run dev
   ```

### Configuration
- Base URL and timeouts configured in `cypress.config.ts`
- TypeScript configuration in `cypress/tsconfig.json`
- Custom commands can be added in `cypress/support/commands.ts`

## Best Practices

### Writing Tests
1. Use descriptive test names that explain the behavior being tested
2. Leverage Mocha hooks for test setup/teardown
3. Use custom timeouts for elements that may take longer to appear
4. Include meaningful assertions using Cypress chainable commands

### Common Patterns
- Visit pages using relative paths: `cy.visit('/path')` instead of full URLs
- Chain assertions: `.should('be.visible').and('have.text', 'expected')`
- Use `beforeEach` hooks for common setup steps
- Handle dynamic content with appropriate waits and retries

### TypeScript Usage
- Define interfaces for structured test data
- Use type annotations for variables and function parameters
- Leverage TypeScript features for better code organization and maintainability

## Project-Specific Notes
- The project uses UI Testing Playground for demonstrations
- Custom timeout values may be needed for certain test scenarios
- XPath selectors require `@cypress/xpath` plugin (already configured)